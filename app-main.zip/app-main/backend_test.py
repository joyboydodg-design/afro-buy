#!/usr/bin/env python3
"""
AfroBuy Marketplace Backend API Testing
Tests all endpoints for the Burkina Faso marketplace application
"""

import requests
import sys
import json
from datetime import datetime
from typing import Dict, Any, Optional

class AfroBuyAPITester:
    def __init__(self, base_url="https://marketplace-africa.preview.emergentagent.com"):
        self.base_url = base_url
        self.seller_token = None
        self.buyer_token = None  
        self.seller_id = None
        self.buyer_id = None
        self.product_id = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_results = []

    def log_test(self, name: str, success: bool, details: str = ""):
        """Log test result"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            status = "✅ PASS"
        else:
            status = "❌ FAIL"
        
        result = f"{status} - {name}"
        if details:
            result += f" | {details}"
        
        print(result)
        self.test_results.append({
            "name": name,
            "success": success, 
            "details": details
        })
        return success

    def run_test(self, name: str, method: str, endpoint: str, expected_status: int, 
                 data: Optional[Dict] = None, headers: Optional[Dict] = None) -> tuple[bool, Dict]:
        """Run a single API test"""
        url = f"{self.base_url}/api/{endpoint}"
        
        default_headers = {'Content-Type': 'application/json'}
        if headers:
            default_headers.update(headers)

        try:
            if method == 'GET':
                response = requests.get(url, headers=default_headers)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=default_headers)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=default_headers)
            elif method == 'DELETE':
                response = requests.delete(url, headers=default_headers)

            success = response.status_code == expected_status
            response_data = {}
            
            try:
                response_data = response.json()
            except:
                response_data = {"raw_response": response.text}

            details = f"Status: {response.status_code}"
            if not success:
                details += f" (expected {expected_status})"
                if 'detail' in response_data:
                    details += f" - {response_data['detail']}"

            self.log_test(name, success, details)
            return success, response_data

        except Exception as e:
            self.log_test(name, False, f"Exception: {str(e)}")
            return False, {}

    def test_categories(self) -> bool:
        """Test getting categories"""
        print("\n🏷️ Testing Categories...")
        success, response = self.run_test(
            "Get Categories",
            "GET", 
            "categories",
            200
        )
        
        if success and isinstance(response, list) and len(response) > 0:
            self.log_test("Categories Content", True, f"Found {len(response)} categories")
            return True
        else:
            self.log_test("Categories Content", False, "No categories returned")
            return False

    def test_seller_registration(self) -> bool:
        """Test seller registration"""
        print("\n👤 Testing Seller Registration...")
        timestamp = datetime.now().strftime('%H%M%S')
        seller_data = {
            "email": f"vendeur{timestamp}@afrobuy.bf",
            "nom": f"Vendeur Test {timestamp}",
            "telephone": f"226{timestamp[:6]}",
            "role": "seller",
            "mot_de_passe": "VendeurPass123!"
        }

        success, response = self.run_test(
            "Register Seller",
            "POST",
            "auth/register", 
            200,
            data=seller_data
        )

        if success and 'access_token' in response:
            self.seller_token = response['access_token']
            self.seller_id = response['user']['id']
            self.log_test("Seller Token Received", True, "JWT token obtained")
            return True
        else:
            self.log_test("Seller Token Received", False, "No token in response")
            return False

    def test_buyer_registration(self) -> bool:
        """Test buyer registration"""
        print("\n🛒 Testing Buyer Registration...")
        timestamp = datetime.now().strftime('%H%M%S')
        buyer_data = {
            "email": f"acheteur{timestamp}@afrobuy.bf", 
            "nom": f"Acheteur Test {timestamp}",
            "telephone": f"226{timestamp[:6]}",
            "role": "buyer",
            "mot_de_passe": "AcheteurPass123!"
        }

        success, response = self.run_test(
            "Register Buyer",
            "POST",
            "auth/register",
            200,
            data=buyer_data  
        )

        if success and 'access_token' in response:
            self.buyer_token = response['access_token']
            self.buyer_id = response['user']['id']
            self.log_test("Buyer Token Received", True, "JWT token obtained")
            return True
        else:
            self.log_test("Buyer Token Received", False, "No token in response")
            return False

    def test_seller_login(self) -> bool:
        """Test seller login"""
        print("\n🔐 Testing Seller Login...")
        if not self.seller_token:
            return False
            
        login_data = {
            "email": f"vendeur{datetime.now().strftime('%H%M%S')}@afrobuy.bf",
            "mot_de_passe": "VendeurPass123!"
        }
        
        # This will fail since we're using a new timestamp, but tests the login endpoint
        success, response = self.run_test(
            "Seller Login",
            "POST", 
            "auth/login",
            401,  # Expected to fail with new email
            data=login_data
        )
        return success

    def test_product_creation(self) -> bool:
        """Test product creation by seller"""
        print("\n📦 Testing Product Creation...")
        if not self.seller_token:
            self.log_test("Product Creation", False, "No seller token available")
            return False

        product_data = {
            "nom": "Mangues Bio du Burkina",
            "description": "Délicieuses mangues biologiques cultivées localement au Burkina Faso",
            "prix": 2500.0,
            "categorie": "alimentation", 
            "stock": 50,
            "images": ["https://example.com/mangue.jpg"]
        }

        headers = {"Authorization": f"Bearer {self.seller_token}"}
        success, response = self.run_test(
            "Create Product",
            "POST",
            "products",
            200,
            data=product_data,
            headers=headers
        )

        if success and 'id' in response:
            self.product_id = response['id']
            self.log_test("Product ID Received", True, f"Product ID: {self.product_id}")
            return True
        else:
            self.log_test("Product ID Received", False, "No product ID in response")
            return False

    def test_get_products(self) -> bool:
        """Test getting all products"""
        print("\n📋 Testing Get Products...")
        success, response = self.run_test(
            "Get All Products",
            "GET",
            "products",
            200
        )
        
        if success and isinstance(response, list):
            self.log_test("Products List", True, f"Retrieved {len(response)} products")
            return True
        else:
            self.log_test("Products List", False, "Invalid products response")
            return False

    def test_product_filtering(self) -> bool:
        """Test product filtering by category"""
        print("\n🔍 Testing Product Filtering...")
        success, response = self.run_test(
            "Filter by Category",
            "GET", 
            "products?categorie=alimentation",
            200
        )
        return success

    def test_product_detail(self) -> bool:
        """Test getting product details"""
        print("\n🔎 Testing Product Details...")
        if not self.product_id:
            self.log_test("Product Detail", False, "No product ID available")
            return False

        success, response = self.run_test(
            "Get Product Detail",
            "GET",
            f"products/{self.product_id}",
            200
        )
        return success

    def test_cart_operations(self) -> bool:
        """Test cart operations"""
        print("\n🛒 Testing Cart Operations...")
        if not self.buyer_token or not self.product_id:
            self.log_test("Cart Operations", False, "Missing buyer token or product ID")
            return False

        headers = {"Authorization": f"Bearer {self.buyer_token}"}
        
        # Get initial cart
        success1, _ = self.run_test(
            "Get Empty Cart",
            "GET",
            "cart", 
            200,
            headers=headers
        )

        # Add item to cart
        cart_items = [{"produit_id": self.product_id, "quantite": 2}]
        success2, _ = self.run_test(
            "Update Cart",
            "POST",
            "cart",
            200,
            data=cart_items,
            headers=headers
        )

        return success1 and success2

    def test_order_creation(self) -> bool:
        """Test order creation"""
        print("\n📝 Testing Order Creation...")
        if not self.buyer_token or not self.product_id:
            self.log_test("Order Creation", False, "Missing buyer token or product ID")
            return False

        order_data = {
            "items": [{
                "produit_id": self.product_id,
                "nom_produit": "Mangues Bio du Burkina",
                "prix": 2500.0,
                "quantite": 2
            }],
            "total": 5000.0,
            "adresse_livraison": "Secteur 15, Ouagadougou, Burkina Faso",
            "telephone": "22670123456"
        }

        headers = {"Authorization": f"Bearer {self.buyer_token}"}
        success, response = self.run_test(
            "Create Order",
            "POST",
            "orders",
            200,
            data=order_data,
            headers=headers
        )
        return success

    def test_reviews(self) -> bool:
        """Test review system"""
        print("\n⭐ Testing Reviews...")
        if not self.buyer_token or not self.product_id:
            self.log_test("Reviews", False, "Missing buyer token or product ID")
            return False

        review_data = {
            "produit_id": self.product_id,
            "note": 5,
            "commentaire": "Excellentes mangues, très sucrées et de bonne qualité!"
        }

        headers = {"Authorization": f"Bearer {self.buyer_token}"}
        success1, _ = self.run_test(
            "Create Review",
            "POST",
            "reviews", 
            200,
            data=review_data,
            headers=headers
        )

        # Get reviews for product
        success2, _ = self.run_test(
            "Get Product Reviews",
            "GET",
            f"reviews/{self.product_id}",
            200
        )

        return success1 and success2

    def test_vendor_endpoints(self) -> bool:
        """Test vendor-specific endpoints"""
        print("\n🏪 Testing Vendor Endpoints...")
        if not self.seller_id:
            self.log_test("Vendor Endpoints", False, "No seller ID available")
            return False

        # Get vendor info
        success1, _ = self.run_test(
            "Get Vendor Info",
            "GET", 
            f"vendors/{self.seller_id}",
            200
        )

        # Get vendor products
        success2, _ = self.run_test(
            "Get Vendor Products", 
            "GET",
            f"vendors/{self.seller_id}/products",
            200
        )

        return success1 and success2

    def run_all_tests(self) -> int:
        """Run all API tests"""
        print("🚀 Starting AfroBuy Marketplace API Testing...\n")
        
        # Test sequence
        tests = [
            self.test_categories,
            self.test_seller_registration,
            self.test_buyer_registration, 
            self.test_seller_login,
            self.test_product_creation,
            self.test_get_products,
            self.test_product_filtering,
            self.test_product_detail,
            self.test_cart_operations,
            self.test_order_creation,
            self.test_reviews,
            self.test_vendor_endpoints
        ]

        for test in tests:
            try:
                test()
            except Exception as e:
                print(f"❌ Test exception: {test.__name__} - {str(e)}")

        # Summary
        print(f"\n📊 Test Results:")
        print(f"Tests passed: {self.tests_passed}/{self.tests_run}")
        success_rate = (self.tests_passed / self.tests_run * 100) if self.tests_run > 0 else 0
        print(f"Success rate: {success_rate:.1f}%")

        if self.tests_passed < self.tests_run:
            print("\n❌ Failed tests:")
            for result in self.test_results:
                if not result['success']:
                    print(f"  - {result['name']}: {result['details']}")

        return 0 if self.tests_passed == self.tests_run else 1


def main():
    tester = AfroBuyAPITester()
    return tester.run_all_tests()


if __name__ == "__main__":
    sys.exit(main())