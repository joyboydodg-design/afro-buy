from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import bcrypt

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

JWT_SECRET = os.environ.get('JWT_SECRET', 'afrobuy-secret-key-2024')
JWT_ALGORITHM = 'HS256'

app = FastAPI()
api_router = APIRouter(prefix="/api")
security = HTTPBearer()

# Models
class UserBase(BaseModel):
    email: EmailStr
    nom: str
    telephone: Optional[str] = None
    role: str = "buyer"  # buyer, seller, admin

class UserRegister(UserBase):
    mot_de_passe: str

class UserLogin(BaseModel):
    email: EmailStr
    mot_de_passe: str

class User(UserBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    date_inscription: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: User

class Product(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    nom: str
    description: str
    prix: float
    categorie: str
    images: List[str] = []
    vendeur_id: str
    vendeur_nom: str
    stock: int = 0
    date_creation: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ProductCreate(BaseModel):
    nom: str
    description: str
    prix: float
    categorie: str
    images: List[str] = []
    stock: int = 0

class ProductUpdate(BaseModel):
    nom: Optional[str] = None
    description: Optional[str] = None
    prix: Optional[float] = None
    categorie: Optional[str] = None
    images: Optional[List[str]] = None
    stock: Optional[int] = None

class CartItem(BaseModel):
    produit_id: str
    quantite: int

class Cart(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    items: List[CartItem] = []
    date_modification: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class OrderItem(BaseModel):
    produit_id: str
    nom_produit: str
    prix: float
    quantite: int

class Order(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    items: List[OrderItem]
    total: float
    adresse_livraison: str
    telephone: str
    statut: str = "en_attente"  # en_attente, confirme, livre
    date_commande: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class OrderCreate(BaseModel):
    items: List[OrderItem]
    total: float
    adresse_livraison: str
    telephone: str

class Review(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    produit_id: str
    user_id: str
    user_nom: str
    note: int  # 1-5
    commentaire: str
    date_avis: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ReviewCreate(BaseModel):
    produit_id: str
    note: int
    commentaire: str

# Auth helpers
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_token(user_id: str) -> str:
    payload = {
        'user_id': user_id,
        'exp': datetime.now(timezone.utc) + timedelta(days=7)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> User:
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = payload.get('user_id')
        user_doc = await db.users.find_one({"id": user_id}, {"_id": 0})
        if not user_doc:
            raise HTTPException(status_code=401, detail="Utilisateur non trouvé")
        if isinstance(user_doc.get('date_inscription'), str):
            user_doc['date_inscription'] = datetime.fromisoformat(user_doc['date_inscription'])
        return User(**user_doc)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expiré")
    except Exception:
        raise HTTPException(status_code=401, detail="Token invalide")

# Routes Auth
@api_router.post("/auth/register", response_model=TokenResponse)
async def register(user_input: UserRegister):
    existing = await db.users.find_one({"email": user_input.email})
    if existing:
        raise HTTPException(status_code=400, detail="Cet email est déjà utilisé")
    
    user_dict = user_input.model_dump(exclude={'mot_de_passe'})
    user_obj = User(**user_dict)
    doc = user_obj.model_dump()
    doc['date_inscription'] = doc['date_inscription'].isoformat()
    doc['mot_de_passe_hash'] = hash_password(user_input.mot_de_passe)
    
    await db.users.insert_one(doc)
    token = create_token(user_obj.id)
    return TokenResponse(access_token=token, user=user_obj)

@api_router.post("/auth/login", response_model=TokenResponse)
async def login(credentials: UserLogin):
    user_doc = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")
    
    if not verify_password(credentials.mot_de_passe, user_doc['mot_de_passe_hash']):
        raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")
    
    if isinstance(user_doc.get('date_inscription'), str):
        user_doc['date_inscription'] = datetime.fromisoformat(user_doc['date_inscription'])
    
    user_doc.pop('mot_de_passe_hash', None)
    user = User(**user_doc)
    token = create_token(user.id)
    return TokenResponse(access_token=token, user=user)

@api_router.get("/auth/me", response_model=User)
async def get_me(current_user: User = Depends(get_current_user)):
    return current_user

# Routes Produits
@api_router.get("/products", response_model=List[Product])
async def get_products(categorie: Optional[str] = None, search: Optional[str] = None, limit: int = 100):
    query = {}
    if categorie:
        query['categorie'] = categorie
    if search:
        query['nom'] = {'$regex': search, '$options': 'i'}
    
    products = await db.products.find(query, {"_id": 0}).limit(limit).to_list(limit)
    for p in products:
        if isinstance(p.get('date_creation'), str):
            p['date_creation'] = datetime.fromisoformat(p['date_creation'])
    return products

@api_router.get("/products/{product_id}", response_model=Product)
async def get_product(product_id: str):
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Produit non trouvé")
    if isinstance(product.get('date_creation'), str):
        product['date_creation'] = datetime.fromisoformat(product['date_creation'])
    return Product(**product)

@api_router.post("/products", response_model=Product)
async def create_product(product_input: ProductCreate, current_user: User = Depends(get_current_user)):
    if current_user.role not in ['seller', 'admin']:
        raise HTTPException(status_code=403, detail="Seuls les vendeurs peuvent ajouter des produits")
    
    product_dict = product_input.model_dump()
    product_dict['vendeur_id'] = current_user.id
    product_dict['vendeur_nom'] = current_user.nom
    product_obj = Product(**product_dict)
    doc = product_obj.model_dump()
    doc['date_creation'] = doc['date_creation'].isoformat()
    
    await db.products.insert_one(doc)
    return product_obj

@api_router.put("/products/{product_id}", response_model=Product)
async def update_product(product_id: str, product_update: ProductUpdate, current_user: User = Depends(get_current_user)):
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Produit non trouvé")
    
    if product['vendeur_id'] != current_user.id and current_user.role != 'admin':
        raise HTTPException(status_code=403, detail="Non autorisé")
    
    update_data = {k: v for k, v in product_update.model_dump().items() if v is not None}
    if update_data:
        await db.products.update_one({"id": product_id}, {"$set": update_data})
    
    updated_product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if isinstance(updated_product.get('date_creation'), str):
        updated_product['date_creation'] = datetime.fromisoformat(updated_product['date_creation'])
    return Product(**updated_product)

@api_router.delete("/products/{product_id}")
async def delete_product(product_id: str, current_user: User = Depends(get_current_user)):
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Produit non trouvé")
    
    if product['vendeur_id'] != current_user.id and current_user.role != 'admin':
        raise HTTPException(status_code=403, detail="Non autorisé")
    
    await db.products.delete_one({"id": product_id})
    return {"message": "Produit supprimé"}

# Routes Catégories
@api_router.get("/categories")
async def get_categories():
    categories = [
        {"id": "alimentation", "nom": "Alimentation", "icon": "🍎"},
        {"id": "vetements", "nom": "Vêtements", "icon": "👕"},
        {"id": "electronique", "nom": "Électronique", "icon": "📱"},
        {"id": "artisanat", "nom": "Artisanat", "icon": "🎨"},
        {"id": "maison", "nom": "Maison & Jardin", "icon": "🏠"},
        {"id": "beaute", "nom": "Beauté & Santé", "icon": "💄"},
    ]
    return categories

# Routes Panier
@api_router.get("/cart", response_model=Cart)
async def get_cart(current_user: User = Depends(get_current_user)):
    cart = await db.carts.find_one({"user_id": current_user.id}, {"_id": 0})
    if not cart:
        cart_obj = Cart(user_id=current_user.id, items=[])
        doc = cart_obj.model_dump()
        doc['date_modification'] = doc['date_modification'].isoformat()
        await db.carts.insert_one(doc)
        return cart_obj
    
    if isinstance(cart.get('date_modification'), str):
        cart['date_modification'] = datetime.fromisoformat(cart['date_modification'])
    return Cart(**cart)

@api_router.post("/cart")
async def update_cart(items: List[CartItem], current_user: User = Depends(get_current_user)):
    cart = await db.carts.find_one({"user_id": current_user.id})
    
    update_data = {
        "items": [item.model_dump() for item in items],
        "date_modification": datetime.now(timezone.utc).isoformat()
    }
    
    if cart:
        await db.carts.update_one({"user_id": current_user.id}, {"$set": update_data})
    else:
        cart_obj = Cart(user_id=current_user.id, items=items)
        doc = cart_obj.model_dump()
        doc['date_modification'] = doc['date_modification'].isoformat()
        await db.carts.insert_one(doc)
    
    return {"message": "Panier mis à jour"}

# Routes Commandes
@api_router.post("/orders", response_model=Order)
async def create_order(order_input: OrderCreate, current_user: User = Depends(get_current_user)):
    order_dict = order_input.model_dump()
    order_dict['user_id'] = current_user.id
    order_obj = Order(**order_dict)
    doc = order_obj.model_dump()
    doc['date_commande'] = doc['date_commande'].isoformat()
    
    await db.orders.insert_one(doc)
    await db.carts.update_one({"user_id": current_user.id}, {"$set": {"items": []}})
    
    return order_obj

@api_router.get("/orders", response_model=List[Order])
async def get_orders(current_user: User = Depends(get_current_user), limit: int = 50):
    query = {}
    if current_user.role == 'buyer':
        query['user_id'] = current_user.id
    elif current_user.role == 'seller':
        products = await db.products.find({"vendeur_id": current_user.id}, {"id": 1, "_id": 0}).to_list(100)
        product_ids = [p['id'] for p in products]
        query['items.produit_id'] = {'$in': product_ids}
    
    orders = await db.orders.find(query, {"_id": 0}).limit(limit).to_list(limit)
    for o in orders:
        if isinstance(o.get('date_commande'), str):
            o['date_commande'] = datetime.fromisoformat(o['date_commande'])
    return orders

# Routes Avis
@api_router.post("/reviews", response_model=Review)
async def create_review(review_input: ReviewCreate, current_user: User = Depends(get_current_user)):
    review_dict = review_input.model_dump()
    review_dict['user_id'] = current_user.id
    review_dict['user_nom'] = current_user.nom
    review_obj = Review(**review_dict)
    doc = review_obj.model_dump()
    doc['date_avis'] = doc['date_avis'].isoformat()
    
    await db.reviews.insert_one(doc)
    return review_obj

@api_router.get("/reviews/{product_id}", response_model=List[Review])
async def get_reviews(product_id: str, limit: int = 50):
    reviews = await db.reviews.find({"produit_id": product_id}, {"_id": 0}).limit(limit).to_list(limit)
    for r in reviews:
        if isinstance(r.get('date_avis'), str):
            r['date_avis'] = datetime.fromisoformat(r['date_avis'])
    return reviews

# Routes Vendeurs
@api_router.get("/vendors/{vendor_id}/products", response_model=List[Product])
async def get_vendor_products(vendor_id: str, limit: int = 100):
    products = await db.products.find({"vendeur_id": vendor_id}, {"_id": 0}).limit(limit).to_list(limit)
    for p in products:
        if isinstance(p.get('date_creation'), str):
            p['date_creation'] = datetime.fromisoformat(p['date_creation'])
    return products

@api_router.get("/vendors/{vendor_id}", response_model=User)
async def get_vendor(vendor_id: str):
    vendor = await db.users.find_one({"id": vendor_id, "role": {"$in": ["seller", "admin"]}}, {"_id": 0, "mot_de_passe_hash": 0})
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendeur non trouvé")
    if isinstance(vendor.get('date_inscription'), str):
        vendor['date_inscription'] = datetime.fromisoformat(vendor['date_inscription'])
    return User(**vendor)

# Admin stats
@api_router.get("/admin/stats")
async def get_admin_stats(current_user: User = Depends(get_current_user)):
    if current_user.role != 'admin':
        raise HTTPException(status_code=403, detail="Accès admin requis")
    
    total_users = await db.users.count_documents({})
    total_products = await db.products.count_documents({})
    total_orders = await db.orders.count_documents({})
    
    return {
        "total_utilisateurs": total_users,
        "total_produits": total_products,
        "total_commandes": total_orders
    }

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
