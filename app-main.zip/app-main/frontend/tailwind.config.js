/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class'],
  content: [
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#006B3F',
          foreground: '#FFFFFF',
          50: '#E6F3ED',
          100: '#CCE7DB',
          500: '#006B3F',
          900: '#002B19',
        },
        secondary: {
          DEFAULT: '#E84D0E',
          foreground: '#FFFFFF',
          50: '#FDEDE7',
          100: '#FBDBCF',
          500: '#E84D0E',
          900: '#5D1F06',
        },
        accent: {
          DEFAULT: '#FCD116',
          foreground: '#1A1A1A',
        },
        background: '#F9F7F1',
        foreground: '#1A1A1A',
        card: {
          DEFAULT: '#FFFFFF',
          foreground: '#1A1A1A',
        },
        popover: {
          DEFAULT: '#FFFFFF',
          foreground: '#1A1A1A',
        },
        muted: {
          DEFAULT: '#F2F0E9',
          foreground: '#646464',
        },
        destructive: {
          DEFAULT: '#DC2626',
          foreground: '#FFFFFF',
        },
        border: '#E5E3DC',
        input: '#E5E3DC',
        ring: '#006B3F',
      },
      fontFamily: {
        sans: ['Outfit', 'Plus Jakarta Sans', 'sans-serif'],
        body: ['Plus Jakarta Sans', 'sans-serif'],
        accent: ['Caveat', 'cursive'],
      },
      borderRadius: {
        lg: '1rem',
        md: '0.75rem',
        sm: '0.5rem',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
}
