import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

const CartContext = createContext();

const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchCart();
    } else {
      setCart([]);
    }
  }, [user]);

  const fetchCart = async () => {
    try {
      const response = await axios.get(`${API_URL}/cart`);
      setCart(response.data.items || []);
    } catch (error) {
      console.error('Erreur lors de la récupération du panier:', error);
    }
  };

  const addToCart = async (produit_id, quantite = 1) => {
    const existingItem = cart.find(item => item.produit_id === produit_id);
    let newCart;
    
    if (existingItem) {
      newCart = cart.map(item => 
        item.produit_id === produit_id 
          ? { ...item, quantite: item.quantite + quantite }
          : item
      );
    } else {
      newCart = [...cart, { produit_id, quantite }];
    }
    
    try {
      await axios.post(`${API_URL}/cart`, newCart);
      setCart(newCart);
    } catch (error) {
      console.error('Erreur lors de l\'ajout au panier:', error);
      throw error;
    }
  };

  const updateQuantity = async (produit_id, quantite) => {
    const newCart = cart.map(item =>
      item.produit_id === produit_id ? { ...item, quantite } : item
    ).filter(item => item.quantite > 0);
    
    try {
      await axios.post(`${API_URL}/cart`, newCart);
      setCart(newCart);
    } catch (error) {
      console.error('Erreur lors de la mise à jour du panier:', error);
    }
  };

  const removeFromCart = async (produit_id) => {
    const newCart = cart.filter(item => item.produit_id !== produit_id);
    try {
      await axios.post(`${API_URL}/cart`, newCart);
      setCart(newCart);
    } catch (error) {
      console.error('Erreur lors de la suppression du panier:', error);
    }
  };

  const clearCart = async () => {
    try {
      await axios.post(`${API_URL}/cart`, []);
      setCart([]);
    } catch (error) {
      console.error('Erreur lors du vidage du panier:', error);
    }
  };

  const cartCount = cart.reduce((total, item) => total + item.quantite, 0);

  return (
    <CartContext.Provider value={{ cart, addToCart, updateQuantity, removeFromCart, clearCart, cartCount, fetchCart }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart doit être utilisé dans un CartProvider');
  }
  return context;
};
