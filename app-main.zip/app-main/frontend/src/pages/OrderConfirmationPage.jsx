import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';
import { Button } from '../components/ui/button';

const OrderConfirmationPage = () => {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center py-12 px-4">
      <div className="max-w-2xl w-full text-center">
        <div className="bg-white rounded-3xl p-12 shadow-2xl">
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle className="h-16 w-16 text-primary" />
          </div>
          <h1 className="text-4xl font-bold mb-4">Commande confirmée !</h1>
          <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
            Merci pour votre commande. Nous avons bien reçu votre demande et nous vous contacterons bientôt pour confirmer la livraison.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/">
              <Button className="bg-secondary hover:bg-secondary/90 text-white rounded-full px-8 py-6 font-semibold">
                Retour à l'accueil
              </Button>
            </Link>
            <Link to="/produits">
              <Button variant="outline" className="border-2 border-primary text-primary hover:bg-primary/5 rounded-full px-8 py-6 font-semibold">
                Continuer mes achats
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmationPage;
