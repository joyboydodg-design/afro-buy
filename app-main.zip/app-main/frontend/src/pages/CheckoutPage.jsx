import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { CheckCircle } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

const CheckoutPage = () => {
  const { user } = useAuth();
  const { cart, clearCart } = useCart();
  const navigate = useNavigate();
  const [cartProducts, setCartProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [orderData, setOrderData] = useState({
    adresse_livraison: '',
    telephone: user?.telephone || ''
  });

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    if (cart.length === 0) {
      navigate('/panier');
      return;
    }
    fetchCartProducts();
  }, [cart, user]);

  const fetchCartProducts = async () => {
    try {
      const productPromises = cart.map(item =>
        axios.get(`${API_URL}/products/${item.produit_id}`)
      );
      const responses = await Promise.all(productPromises);
      const products = responses.map((res, idx) => ({
        ...res.data,
        quantite: cart[idx].quantite
      }));
      setCartProducts(products);
    } catch (error) {
      console.error('Erreur:', error);
    } finally {
      setLoading(false);
    }
  };

  const total = cartProducts.reduce((sum, item) => sum + (item.prix * item.quantite), 0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const orderItems = cartProducts.map(p => ({
        produit_id: p.id,
        nom_produit: p.nom,
        prix: p.prix,
        quantite: p.quantite
      }));

      await axios.post(`${API_URL}/orders`, {
        items: orderItems,
        total,
        ...orderData
      });

      toast.success('Commande passée avec succès !');
      await clearCart();
      navigate('/commande/confirmation');
    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors de la commande');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground text-lg">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12" data-testid="checkout-page">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-4xl">
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Finaliser la commande</h1>
          <p className="text-muted-foreground text-lg">Complétez vos informations de livraison</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-3xl p-8">
              <h2 className="text-2xl font-bold mb-6">Informations de livraison</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="phone">Téléphone</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={orderData.telephone}
                    onChange={(e) => setOrderData({ ...orderData, telephone: e.target.value })}
                    required
                    placeholder="+226 XX XX XX XX"
                    className="h-12 rounded-xl border-2"
                    data-testid="checkout-phone-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Adresse de livraison</Label>
                  <Textarea
                    id="address"
                    value={orderData.adresse_livraison}
                    onChange={(e) => setOrderData({ ...orderData, adresse_livraison: e.target.value })}
                    required
                    placeholder="Entrez votre adresse complète"
                    className="min-h-24 rounded-xl border-2"
                    data-testid="checkout-address-input"
                  />
                </div>

                <div className="bg-muted/50 rounded-2xl p-6">
                  <h3 className="font-semibold text-lg mb-4">Mode de paiement</h3>
                  <div className="bg-white rounded-xl p-4 border-2 border-primary">
                    <p className="font-medium">Paiement à la livraison</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Vous payerez en espèces lors de la réception de votre commande
                    </p>
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-secondary hover:bg-secondary/90 text-white rounded-full px-8 py-6 font-semibold shadow-lg hover:shadow-xl transition-all active:scale-95 text-lg"
                  data-testid="confirm-order-button"
                >
                  {submitting ? 'Traitement...' : 'Confirmer la commande'}
                </Button>
              </form>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl p-8 sticky top-24">
              <h2 className="text-xl font-bold mb-6">Résumé de la commande</h2>
              <div className="space-y-4 mb-6">
                {cartProducts.map((product) => (
                  <div key={product.id} className="flex gap-3">
                    <div className="w-16 h-16 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                      {product.images && product.images.length > 0 ? (
                        <img src={product.images[0]} alt={product.nom} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
                          Pas d'image
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm line-clamp-2">{product.nom}</p>
                      <p className="text-sm text-muted-foreground">Qty: {product.quantite}</p>
                    </div>
                    <p className="font-semibold text-sm">{(product.prix * product.quantite).toLocaleString()} FCFA</p>
                  </div>
                ))}
              </div>
              <div className="border-t border-border pt-6 space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Sous-total</span>
                  <span className="font-semibold">{total.toLocaleString()} FCFA</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Livraison</span>
                  <span className="font-semibold text-primary">Gratuite</span>
                </div>
                <div className="flex justify-between pt-3 border-t border-border">
                  <span className="text-xl font-bold">Total</span>
                  <span className="text-2xl font-bold text-primary">{total.toLocaleString()} FCFA</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
