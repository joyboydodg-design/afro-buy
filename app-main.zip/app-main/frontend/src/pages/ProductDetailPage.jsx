import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Star, ShoppingCart, Store, ArrowLeft } from 'lucide-react';
import { Button } from '../components/ui/button';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';

const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

const ProductDetailPage = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const { addToCart } = useCart();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [newReview, setNewReview] = useState({ note: 5, commentaire: '' });
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    fetchProductDetails();
  }, [id]);

  const fetchProductDetails = async () => {
    try {
      const [productRes, reviewsRes] = await Promise.all([
        axios.get(`${API_URL}/products/${id}`),
        axios.get(`${API_URL}/reviews/${id}`)
      ]);
      setProduct(productRes.data);
      setReviews(reviewsRes.data);
    } catch (error) {
      console.error('Erreur lors du chargement:', error);
      toast.error('Produit non trouvé');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async () => {
    if (!user) {
      toast.error('Veuillez vous connecter pour ajouter au panier');
      navigate('/auth');
      return;
    }
    try {
      await addToCart(product.id, 1);
      toast.success('Produit ajouté au panier !');
    } catch (error) {
      toast.error('Erreur lors de l\'ajout au panier');
    }
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    if (!user) {
      toast.error('Veuillez vous connecter pour laisser un avis');
      navigate('/auth');
      return;
    }
    setSubmittingReview(true);
    try {
      await axios.post(`${API_URL}/reviews`, {
        produit_id: product.id,
        ...newReview
      });
      toast.success('Avis ajouté avec succès !');
      setNewReview({ note: 5, commentaire: '' });
      fetchProductDetails();
    } catch (error) {
      toast.error('Erreur lors de l\'ajout de l\'avis');
    } finally {
      setSubmittingReview(false);
    }
  };

  const averageRating = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.note, 0) / reviews.length).toFixed(1)
    : 0;

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground text-lg">Chargement...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground text-lg mb-4">Produit non trouvé</p>
          <Link to="/produits">
            <Button>Retour aux produits</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12" data-testid="product-detail-page">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl">
        <Link to="/produits" className="inline-flex items-center text-primary hover:underline mb-8">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Retour aux produits
        </Link>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          <div>
            <div className="bg-white rounded-3xl overflow-hidden mb-4 aspect-square">
              {product.images && product.images.length > 0 ? (
                <img
                  src={product.images[selectedImage]}
                  alt={product.nom}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-muted text-muted-foreground">
                  Pas d'image
                </div>
              )}
            </div>
            {product.images && product.images.length > 1 && (
              <div className="grid grid-cols-4 gap-4">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`aspect-square rounded-xl overflow-hidden border-2 ${
                      selectedImage === idx ? 'border-primary' : 'border-border'
                    }`}
                  >
                    <img src={img} alt={`${product.nom} ${idx + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4" data-testid="product-name">{product.nom}</h1>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-2">
                  {Array.from({length: 5}, (_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.round(averageRating) ? 'fill-accent text-accent' : 'text-muted-foreground'
                      }`}
                    />
                  ))}
                  <span className="font-medium">{averageRating}</span>
                </div>
                <span className="text-muted-foreground">({reviews.length} avis)</span>
              </div>
              <p className="text-4xl font-bold text-primary mb-6" data-testid="product-price">{product.prix.toLocaleString()} FCFA</p>
            </div>

            <div className="border-t border-b border-border py-6">
              <h2 className="font-semibold text-xl mb-3">Description</h2>
              <p className="text-muted-foreground leading-relaxed" data-testid="product-description">{product.description}</p>
            </div>

            <div className="flex items-center gap-4 py-4">
              <Store className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Vendu par</p>
                <Link
                  to={`/boutique/${product.vendeur_id}`}
                  className="font-semibold text-primary hover:underline"
                >
                  {product.vendeur_nom}
                </Link>
              </div>
            </div>

            <div className="space-y-3">
              <p className="text-sm">
                <span className="font-medium">Catégorie:</span>{' '}
                <span className="text-muted-foreground">{product.categorie}</span>
              </p>
              <p className="text-sm">
                <span className="font-medium">Stock:</span>{' '}
                <span className={product.stock > 0 ? 'text-primary' : 'text-destructive'}>
                  {product.stock > 0 ? `${product.stock} disponible(s)` : 'Rupture de stock'}
                </span>
              </p>
            </div>

            <div className="pt-6">
              <Button
                onClick={handleAddToCart}
                disabled={product.stock === 0}
                className="w-full bg-secondary hover:bg-secondary/90 text-white rounded-full px-8 py-6 font-semibold shadow-lg hover:shadow-xl transition-all active:scale-95 text-lg"
                data-testid="add-to-cart-button"
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                {product.stock === 0 ? 'Rupture de stock' : 'Ajouter au panier'}
              </Button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-8 md:p-12 mb-8">
          <h2 className="text-3xl font-bold mb-8">Avis clients</h2>
          
          {user && (
            <form onSubmit={handleSubmitReview} className="mb-12 p-6 bg-muted/30 rounded-2xl" data-testid="review-form">
              <h3 className="font-semibold text-xl mb-4">Laisser un avis</h3>
              <div className="space-y-4">
                <div>
                  <Label>Note</Label>
                  <div className="flex gap-2 mt-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewReview({ ...newReview, note: star })}
                        className="focus:outline-none"
                      >
                        <Star
                          className={`h-8 w-8 cursor-pointer ${
                            star <= newReview.note ? 'fill-accent text-accent' : 'text-muted-foreground'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <Label htmlFor="comment">Commentaire</Label>
                  <Textarea
                    id="comment"
                    value={newReview.commentaire}
                    onChange={(e) => setNewReview({ ...newReview, commentaire: e.target.value })}
                    placeholder="Partagez votre expérience avec ce produit..."
                    required
                    className="mt-2 min-h-24"
                    data-testid="review-comment-input"
                  />
                </div>
                <Button
                  type="submit"
                  disabled={submittingReview}
                  className="bg-primary hover:bg-primary-900 text-white rounded-full px-6 py-4"
                  data-testid="submit-review-button"
                >
                  {submittingReview ? 'Envoi...' : 'Publier l\'avis'}
                </Button>
              </div>
            </form>
          )}

          <div className="space-y-6" data-testid="reviews-list">
            {reviews.length > 0 ? (
              reviews.map((review) => (
                <div key={review.id} className="border-b border-border pb-6 last:border-0">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-semibold">{review.user_nom}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(review.date_avis).toLocaleDateString('fr-FR')}
                      </p>
                    </div>
                    <div className="flex">
                      {Array.from({length: 5}, (_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < review.note ? 'fill-accent text-accent' : 'text-muted-foreground'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{review.commentaire}</p>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground text-center py-8">Aucun avis pour le moment. Soyez le premier à donner votre avis !</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
