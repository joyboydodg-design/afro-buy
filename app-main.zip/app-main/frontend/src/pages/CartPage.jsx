import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { Button } from '../components/ui/button';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

const CartPage = () => {
  const { user } = useAuth();
  const { cart, updateQuantity, removeFromCart } = useCart();
  const navigate = useNavigate();
  const [cartProducts, setCartProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    fetchCartProducts();
  }, [cart, user]);

  const fetchCartProducts = async () => {
    if (cart.length === 0) {
      setCartProducts([]);
      setLoading(false);
      return;
    }

    try {
      const productPromises = cart.map(item =>
        axios.get(`${API_URL}/products/${item.produit_id}`)
      );
      const responses = await Promise.all(productPromises);
      const products = responses.map((res, idx) => ({
        ...res.data,
        quantite: cart[idx].quantite
      }));
      setCartProducts(products);
    } catch (error) {
      console.error('Erreur lors du chargement des produits du panier:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateQuantity = async (produit_id, newQuantity) => {
    if (newQuantity < 1) return;
    try {
      await updateQuantity(produit_id, newQuantity);
    } catch (error) {
      toast.error('Erreur lors de la mise à jour');
    }
  };

  const handleRemove = async (produit_id) => {
    try {
      await removeFromCart(produit_id);
      toast.success('Produit retiré du panier');
    } catch (error) {
      toast.error('Erreur lors de la suppression');
    }
  };

  const total = cartProducts.reduce((sum, item) => sum + (item.prix * item.quantite), 0);

  const handleCheckout = () => {
    navigate('/commande');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground text-lg">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12" data-testid="cart-page">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl">
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Mon panier</h1>
          <p className="text-muted-foreground text-lg">
            {cartProducts.length} article{cartProducts.length > 1 ? 's' : ''} dans votre panier
          </p>
        </div>

        {cartProducts.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl">
            <ShoppingBag className="h-20 w-20 text-muted-foreground mx-auto mb-6" />
            <h2 className="text-2xl font-semibold mb-4">Votre panier est vide</h2>
            <p className="text-muted-foreground mb-8">Découvrez nos produits et ajoutez-en à votre panier</p>
            <Link to="/produits">
              <Button className="bg-secondary hover:bg-secondary/90 text-white rounded-full px-8 py-6 font-semibold">
                Découvrir les produits
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              {cartProducts.map((product) => (
                <div
                  key={product.id}
                  className="bg-white rounded-2xl p-6 flex gap-6 items-start hover:shadow-lg transition-shadow"
                  data-testid={`cart-item-${product.id}`}
                >
                  <Link to={`/produit/${product.id}`} className="flex-shrink-0">
                    <div className="w-24 h-24 rounded-xl overflow-hidden bg-muted">
                      {product.images && product.images.length > 0 ? (
                        <img
                          src={product.images[0]}
                          alt={product.nom}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
                          Pas d'image
                        </div>
                      )}
                    </div>
                  </Link>

                  <div className="flex-1">
                    <Link to={`/produit/${product.id}`}>
                      <h3 className="font-semibold text-lg mb-2 hover:text-primary transition-colors">
                        {product.nom}
                      </h3>
                    </Link>
                    <p className="text-primary font-bold text-xl mb-4">
                      {product.prix.toLocaleString()} FCFA
                    </p>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center border-2 border-border rounded-full overflow-hidden">
                        <button
                          onClick={() => handleUpdateQuantity(product.id, product.quantite - 1)}
                          className="px-4 py-2 hover:bg-muted transition-colors"
                          data-testid={`decrease-quantity-${product.id}`}
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="px-6 py-2 font-semibold" data-testid={`quantity-${product.id}`}>{product.quantite}</span>
                        <button
                          onClick={() => handleUpdateQuantity(product.id, product.quantite + 1)}
                          className="px-4 py-2 hover:bg-muted transition-colors"
                          data-testid={`increase-quantity-${product.id}`}
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                      <button
                        onClick={() => handleRemove(product.id)}
                        className="text-destructive hover:bg-destructive/10 p-2 rounded-full transition-colors"
                        data-testid={`remove-item-${product.id}`}
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="text-sm text-muted-foreground mb-2">Sous-total</p>
                    <p className="font-bold text-xl text-primary">
                      {(product.prix * product.quantite).toLocaleString()} FCFA
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl p-8 sticky top-24">
                <h2 className="text-2xl font-bold mb-6">Résumé</h2>
                <div className="space-y-4 mb-6 pb-6 border-b border-border">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Sous-total</span>
                    <span className="font-semibold">{total.toLocaleString()} FCFA</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Livraison</span>
                    <span className="font-semibold text-primary">Gratuite</span>
                  </div>
                </div>
                <div className="flex justify-between mb-8">
                  <span className="text-xl font-bold">Total</span>
                  <span className="text-2xl font-bold text-primary" data-testid="cart-total">{total.toLocaleString()} FCFA</span>
                </div>
                <Button
                  onClick={handleCheckout}
                  className="w-full bg-secondary hover:bg-secondary/90 text-white rounded-full px-8 py-6 font-semibold shadow-lg hover:shadow-xl transition-all active:scale-95 text-lg"
                  data-testid="checkout-button"
                >
                  Passer la commande
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartPage;
