import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Users, Package, ShoppingBag, TrendingUp } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

const AdminDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    total_utilisateurs: 0,
    total_produits: 0,
    total_commandes: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    fetchStats();
  }, [user]);

  const fetchStats = async () => {
    try {
      const response = await axios.get(`${API_URL}/admin/stats`);
      setStats(response.data);
    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors du chargement des statistiques');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground text-lg">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12" data-testid="admin-dashboard">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl">
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Tableau de bord admin</h1>
          <p className="text-muted-foreground text-lg">Bienvenue, {user.nom}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          <div className="bg-white rounded-3xl p-8 hover:shadow-xl transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center">
                <Users className="h-7 w-7 text-primary" />
              </div>
              <TrendingUp className="h-5 w-5 text-primary" />
            </div>
            <p className="text-muted-foreground mb-2">Total utilisateurs</p>
            <p className="text-4xl font-bold text-foreground" data-testid="total-users">{stats.total_utilisateurs}</p>
          </div>

          <div className="bg-white rounded-3xl p-8 hover:shadow-xl transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className="w-14 h-14 bg-secondary/10 rounded-2xl flex items-center justify-center">
                <Package className="h-7 w-7 text-secondary" />
              </div>
              <TrendingUp className="h-5 w-5 text-secondary" />
            </div>
            <p className="text-muted-foreground mb-2">Total produits</p>
            <p className="text-4xl font-bold text-foreground" data-testid="total-products">{stats.total_produits}</p>
          </div>

          <div className="bg-white rounded-3xl p-8 hover:shadow-xl transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className="w-14 h-14 bg-accent/20 rounded-2xl flex items-center justify-center">
                <ShoppingBag className="h-7 w-7 text-accent-foreground" />
              </div>
              <TrendingUp className="h-5 w-5 text-accent-foreground" />
            </div>
            <p className="text-muted-foreground mb-2">Total commandes</p>
            <p className="text-4xl font-bold text-foreground" data-testid="total-orders">{stats.total_commandes}</p>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-8">
          <h2 className="text-3xl font-bold mb-6">Vue d'ensemble</h2>
          <p className="text-muted-foreground leading-relaxed">
            Le tableau de bord administrateur vous permet de surveiller les activités de la plateforme AfroBuy. 
            Vous pouvez voir le nombre total d'utilisateurs, de produits et de commandes en temps réel.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
