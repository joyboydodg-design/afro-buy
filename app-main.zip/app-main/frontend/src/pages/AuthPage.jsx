import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { toast } from 'sonner';

const AuthPage = () => {
  const [loginData, setLoginData] = useState({ email: '', mot_de_passe: '' });
  const [registerData, setRegisterData] = useState({
    email: '',
    mot_de_passe: '',
    nom: '',
    telephone: '',
    role: 'buyer'
  });
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(loginData.email, loginData.mot_de_passe);
      toast.success('Connexion réussie !');
      navigate('/');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erreur lors de la connexion');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await register(registerData);
      toast.success('Inscription réussie !');
      navigate('/');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erreur lors de l\'inscription');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F9F7F1] via-[#E6F3ED] to-[#F9F7F1] flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-6xl grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
        <div className="hidden md:block">
          <img
            src="https://images.unsplash.com/photo-1642165835095-528b68f00663?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzl8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwaGFwcHklMjBwZXJzb24lMjBwb3J0cmFpdCUyMHVzaW5nJTIwcGhvbmV8ZW58MHx8fHwxNzY5OTk1OTEyfDA&ixlib=rb-4.1.0&q=85"
            alt="Bienvenue sur AfroBuy"
            className="rounded-3xl shadow-2xl w-full"
          />
          <div className="mt-8">
            <h2 className="text-3xl font-bold text-foreground mb-4">Rejoignez AfroBuy</h2>
            <p className="text-muted-foreground leading-relaxed">
              La marketplace qui connecte acheteurs et vendeurs du Burkina Faso. Créez votre compte et commencez à acheter ou vendre dès aujourd'hui.
            </p>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-10" data-testid="auth-form">
          <div className="mb-8">
            <Link to="/" className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary-900 rounded-2xl flex items-center justify-center shadow-lg">
                <span className="text-2xl font-bold text-white">A</span>
              </div>
              <span className="text-2xl font-bold text-primary">AfroBuy</span>
            </Link>
            <h1 className="text-3xl font-bold text-foreground">Bienvenue</h1>
            <p className="text-muted-foreground mt-2">Connectez-vous ou créez un compte</p>
          </div>

          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="login" data-testid="login-tab">Connexion</TabsTrigger>
              <TabsTrigger value="register" data-testid="register-tab">Inscription</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="login-email">Email</Label>
                  <Input
                    id="login-email"
                    type="email"
                    placeholder="votre@email.com"
                    value={loginData.email}
                    onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                    required
                    className="h-12 rounded-xl border-2 border-input focus:border-primary focus:ring-4 focus:ring-primary/10 bg-white transition-all"
                    data-testid="login-email-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password">Mot de passe</Label>
                  <Input
                    id="login-password"
                    type="password"
                    placeholder="••••••••"
                    value={loginData.mot_de_passe}
                    onChange={(e) => setLoginData({ ...loginData, mot_de_passe: e.target.value })}
                    required
                    className="h-12 rounded-xl border-2 border-input focus:border-primary focus:ring-4 focus:ring-primary/10 bg-white transition-all"
                    data-testid="login-password-input"
                  />
                </div>
                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-secondary hover:bg-secondary/90 text-white rounded-full px-8 py-6 font-semibold shadow-lg hover:shadow-xl transition-all active:scale-95"
                  data-testid="login-submit-button"
                >
                  {loading ? 'Connexion...' : 'Se connecter'}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="register">
              <form onSubmit={handleRegister} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="register-name">Nom complet</Label>
                  <Input
                    id="register-name"
                    type="text"
                    placeholder="Votre nom"
                    value={registerData.nom}
                    onChange={(e) => setRegisterData({ ...registerData, nom: e.target.value })}
                    required
                    className="h-12 rounded-xl border-2 border-input focus:border-primary focus:ring-4 focus:ring-primary/10 bg-white transition-all"
                    data-testid="register-name-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-email">Email</Label>
                  <Input
                    id="register-email"
                    type="email"
                    placeholder="votre@email.com"
                    value={registerData.email}
                    onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                    required
                    className="h-12 rounded-xl border-2 border-input focus:border-primary focus:ring-4 focus:ring-primary/10 bg-white transition-all"
                    data-testid="register-email-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-phone">Téléphone</Label>
                  <Input
                    id="register-phone"
                    type="tel"
                    placeholder="+226 XX XX XX XX"
                    value={registerData.telephone}
                    onChange={(e) => setRegisterData({ ...registerData, telephone: e.target.value })}
                    className="h-12 rounded-xl border-2 border-input focus:border-primary focus:ring-4 focus:ring-primary/10 bg-white transition-all"
                    data-testid="register-phone-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-password">Mot de passe</Label>
                  <Input
                    id="register-password"
                    type="password"
                    placeholder="••••••••"
                    value={registerData.mot_de_passe}
                    onChange={(e) => setRegisterData({ ...registerData, mot_de_passe: e.target.value })}
                    required
                    className="h-12 rounded-xl border-2 border-input focus:border-primary focus:ring-4 focus:ring-primary/10 bg-white transition-all"
                    data-testid="register-password-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-role">Type de compte</Label>
                  <select
                    id="register-role"
                    value={registerData.role}
                    onChange={(e) => setRegisterData({ ...registerData, role: e.target.value })}
                    className="w-full h-12 rounded-xl border-2 border-input focus:border-primary focus:ring-4 focus:ring-primary/10 bg-white transition-all px-4"
                    data-testid="register-role-select"
                  >
                    <option value="buyer">Acheteur</option>
                    <option value="seller">Vendeur</option>
                  </select>
                </div>
                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-secondary hover:bg-secondary/90 text-white rounded-full px-8 py-6 font-semibold shadow-lg hover:shadow-xl transition-all active:scale-95"
                  data-testid="register-submit-button"
                >
                  {loading ? 'Inscription...' : 'Créer un compte'}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
