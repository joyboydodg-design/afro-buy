import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { Plus, Pencil, Trash2, Package } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../components/ui/dialog';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';

const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

const VendorDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [productForm, setProductForm] = useState({
    nom: '',
    description: '',
    prix: '',
    categorie: '',
    stock: '',
    images: []
  });

  useEffect(() => {
    if (!user || user.role !== 'seller') {
      navigate('/');
      return;
    }
    fetchData();
  }, [user]);

  const fetchData = async () => {
    try {
      const [productsRes, ordersRes, categoriesRes] = await Promise.all([
        axios.get(`${API_URL}/vendors/${user.id}/products`),
        axios.get(`${API_URL}/orders`),
        axios.get(`${API_URL}/categories`)
      ]);
      setProducts(productsRes.data);
      setOrders(ordersRes.data);
      setCategories(categoriesRes.data);
    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors du chargement des données');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = {
        ...productForm,
        prix: parseFloat(productForm.prix),
        stock: parseInt(productForm.stock)
      };

      if (editingProduct) {
        await axios.put(`${API_URL}/products/${editingProduct.id}`, data);
        toast.success('Produit mis à jour !');
      } else {
        await axios.post(`${API_URL}/products`, data);
        toast.success('Produit ajouté !');
      }

      setIsDialogOpen(false);
      setEditingProduct(null);
      setProductForm({ nom: '', description: '', prix: '', categorie: '', stock: '', images: [] });
      fetchData();
    } catch (error) {
      toast.error('Erreur lors de l\'enregistrement');
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setProductForm({
      nom: product.nom,
      description: product.description,
      prix: product.prix.toString(),
      categorie: product.categorie,
      stock: product.stock.toString(),
      images: product.images || []
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (productId) => {
    if (!window.confirm('Êtes-vous sûr de vouloir supprimer ce produit ?')) return;
    try {
      await axios.delete(`${API_URL}/products/${productId}`);
      toast.success('Produit supprimé');
      fetchData();
    } catch (error) {
      toast.error('Erreur lors de la suppression');
    }
  };

  const handleImageUrlChange = (index, value) => {
    const newImages = [...productForm.images];
    newImages[index] = value;
    setProductForm({ ...productForm, images: newImages });
  };

  const addImageField = () => {
    setProductForm({ ...productForm, images: [...productForm.images, ''] });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground text-lg">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12" data-testid="vendor-dashboard">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl">
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Tableau de bord vendeur</h1>
          <p className="text-muted-foreground text-lg">Bienvenue, {user.nom}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-2xl p-8">
            <p className="text-muted-foreground mb-2">Mes produits</p>
            <p className="text-4xl font-bold text-primary">{products.length}</p>
          </div>
          <div className="bg-white rounded-2xl p-8">
            <p className="text-muted-foreground mb-2">Commandes reçues</p>
            <p className="text-4xl font-bold text-secondary">{orders.length}</p>
          </div>
          <div className="bg-white rounded-2xl p-8">
            <p className="text-muted-foreground mb-2">Produits en stock</p>
            <p className="text-4xl font-bold text-accent-foreground">{products.filter(p => p.stock > 0).length}</p>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold">Mes produits</h2>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  onClick={() => {
                    setEditingProduct(null);
                    setProductForm({ nom: '', description: '', prix: '', categorie: '', stock: '', images: [] });
                  }}
                  className="bg-secondary hover:bg-secondary/90 text-white rounded-full px-6 py-4 font-semibold"
                  data-testid="add-product-button"
                >
                  <Plus className="mr-2 h-5 w-5" />
                  Ajouter un produit
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-2xl">
                    {editingProduct ? 'Modifier le produit' : 'Ajouter un produit'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-6 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="nom">Nom du produit</Label>
                    <Input
                      id="nom"
                      value={productForm.nom}
                      onChange={(e) => setProductForm({ ...productForm, nom: e.target.value })}
                      required
                      className="h-12 rounded-xl"
                      data-testid="product-name-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={productForm.description}
                      onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                      required
                      className="min-h-24 rounded-xl"
                      data-testid="product-description-input"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="prix">Prix (FCFA)</Label>
                      <Input
                        id="prix"
                        type="number"
                        value={productForm.prix}
                        onChange={(e) => setProductForm({ ...productForm, prix: e.target.value })}
                        required
                        className="h-12 rounded-xl"
                        data-testid="product-price-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="stock">Stock</Label>
                      <Input
                        id="stock"
                        type="number"
                        value={productForm.stock}
                        onChange={(e) => setProductForm({ ...productForm, stock: e.target.value })}
                        required
                        className="h-12 rounded-xl"
                        data-testid="product-stock-input"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="categorie">Catégorie</Label>
                    <select
                      id="categorie"
                      value={productForm.categorie}
                      onChange={(e) => setProductForm({ ...productForm, categorie: e.target.value })}
                      required
                      className="w-full h-12 rounded-xl border-2 border-input focus:border-primary focus:ring-4 focus:ring-primary/10 bg-white px-4"
                      data-testid="product-category-select"
                    >
                      <option value="">Sélectionnez une catégorie</option>
                      {categories.map(cat => (
                        <option key={cat.id} value={cat.id}>{cat.nom}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label>Images (URLs)</Label>
                    {productForm.images.map((img, idx) => (
                      <Input
                        key={idx}
                        value={img}
                        onChange={(e) => handleImageUrlChange(idx, e.target.value)}
                        placeholder="https://exemple.com/image.jpg"
                        className="h-12 rounded-xl"
                      />
                    ))}
                    <Button type="button" variant="outline" onClick={addImageField} className="w-full">
                      Ajouter une image
                    </Button>
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-secondary hover:bg-secondary/90 text-white rounded-full px-8 py-6 font-semibold"
                    data-testid="save-product-button"
                  >
                    {editingProduct ? 'Mettre à jour' : 'Ajouter'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {products.length === 0 ? (
            <div className="text-center py-12 bg-muted/30 rounded-2xl">
              <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">Vous n'avez pas encore de produits</p>
              <p className="text-sm text-muted-foreground">Cliquez sur "Ajouter un produit" pour commencer</p>
            </div>
          ) : (
            <div className="space-y-4" data-testid="products-list">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="flex gap-6 p-6 border-2 border-border rounded-2xl hover:border-primary/50 transition-colors"
                  data-testid={`product-item-${product.id}`}
                >
                  <div className="w-24 h-24 rounded-xl overflow-hidden bg-muted flex-shrink-0">
                    {product.images && product.images.length > 0 ? (
                      <img src={product.images[0]} alt={product.nom} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
                        Pas d'image
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-xl mb-2">{product.nom}</h3>
                    <p className="text-muted-foreground mb-3 line-clamp-2">{product.description}</p>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="font-bold text-primary text-lg">{product.prix.toLocaleString()} FCFA</span>
                      <span className="text-muted-foreground">Stock: {product.stock}</span>
                      <span className="text-muted-foreground">Catégorie: {product.categorie}</span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleEdit(product)}
                      className="rounded-full"
                      data-testid={`edit-product-${product.id}`}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleDelete(product.id)}
                      className="rounded-full text-destructive hover:text-destructive"
                      data-testid={`delete-product-${product.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VendorDashboard;
