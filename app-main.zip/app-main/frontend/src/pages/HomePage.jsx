import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { ArrowRight, TrendingUp, Shield, Zap } from 'lucide-react';
import { Button } from '../components/ui/button';
import { ProductCard } from '../components/ProductCard';

const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

const HomePage = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [productsRes, categoriesRes] = await Promise.all([
        axios.get(`${API_URL}/products`),
        axios.get(`${API_URL}/categories`)
      ]);
      setProducts(productsRes.data.slice(0, 8));
      setCategories(categoriesRes.data);
    } catch (error) {
      console.error('Erreur lors du chargement:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <section className="bg-gradient-to-br from-[#F9F7F1] via-[#E6F3ED] to-[#F9F7F1] py-20 md:py-32">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-center">
            <div className="md:col-span-7 space-y-8">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground leading-tight">
                Votre marché local,
                <span className="text-primary"> en ligne</span>
              </h1>
              <p className="text-base md:text-lg leading-relaxed text-muted-foreground max-w-2xl">
                Découvrez les meilleurs produits du Burkina Faso. Achetez et vendez en toute sécurité sur AfroBuy, la marketplace qui connecte acheteurs et vendeurs locaux.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/produits">
                  <Button className="bg-secondary hover:bg-secondary/90 text-white rounded-full px-8 py-6 font-semibold shadow-lg hover:shadow-xl transition-all active:scale-95" data-testid="explore-products-button">
                    Explorer les produits
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link to="/auth">
                  <Button variant="outline" className="border-2 border-primary text-primary hover:bg-primary/5 rounded-full px-8 py-6 font-semibold transition-all" data-testid="become-seller-button">
                    Devenir vendeur
                  </Button>
                </Link>
              </div>
            </div>
            <div className="md:col-span-5">
              <img
                src="https://images.unsplash.com/photo-1749938505996-93a421dd09c0?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2Njd8MHwxfHNlYXJjaHwzfHxhZnJpY2FuJTIwbWFya2V0JTIwYnVzdGxpbmclMjBjb2xvcmZ1bCUyMHNjZW5lfGVufDB8fHx8MTc2OTk5NTg5OHww&ixlib=rb-4.1.0&q=85"
                alt="Marché africain"
                className="rounded-3xl shadow-2xl w-full"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-muted/50 rounded-3xl p-8 hover:bg-white hover:shadow-lg transition-all duration-300">
              <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
                <Shield className="h-7 w-7 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Paiement sécurisé</h3>
              <p className="text-muted-foreground leading-relaxed">
                Vos transactions sont protégées et sécurisées pour une expérience d'achat sereine.
              </p>
            </div>
            <div className="bg-muted/50 rounded-3xl p-8 hover:bg-white hover:shadow-lg transition-all duration-300">
              <div className="w-14 h-14 bg-secondary/10 rounded-2xl flex items-center justify-center mb-4">
                <Zap className="h-7 w-7 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Livraison rapide</h3>
              <p className="text-muted-foreground leading-relaxed">
                Recevez vos commandes rapidement grâce à notre réseau de livraison efficace.
              </p>
            </div>
            <div className="bg-muted/50 rounded-3xl p-8 hover:bg-white hover:shadow-lg transition-all duration-300">
              <div className="w-14 h-14 bg-accent/20 rounded-2xl flex items-center justify-center mb-4">
                <TrendingUp className="h-7 w-7 text-accent-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Produits locaux</h3>
              <p className="text-muted-foreground leading-relaxed">
                Soutenez l'économie locale en achetant directement auprès de vendeurs burkinabés.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 md:py-24 bg-background">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-semibold tracking-tight mb-2">Catégories populaires</h2>
              <p className="text-muted-foreground">Explorez nos différentes catégories</p>
            </div>
            <Link to="/produits">
              <Button variant="ghost" className="text-primary hover:bg-primary/5 rounded-lg px-4 py-2 font-medium">
                Voir tout
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <Link key={category.id} to={`/produits?categorie=${category.id}`} data-testid={`category-${category.id}`}>
                <div className="bg-white rounded-2xl p-6 text-center hover:shadow-lg transition-all duration-300 hover:scale-105 border border-border">
                  <div className="text-4xl mb-3">{category.icon}</div>
                  <p className="font-semibold text-sm">{category.nom}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 md:py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-semibold tracking-tight mb-2">Produits vedettes</h2>
              <p className="text-muted-foreground">Découvrez notre sélection du moment</p>
            </div>
            <Link to="/produits">
              <Button variant="ghost" className="text-primary hover:bg-primary/5 rounded-lg px-4 py-2 font-medium">
                Voir tout
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
          {loading ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Chargement des produits...</p>
            </div>
          ) : products.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-muted/30 rounded-3xl">
              <p className="text-muted-foreground mb-4">Aucun produit disponible pour le moment</p>
              <Link to="/auth">
                <Button className="bg-secondary hover:bg-secondary/90 text-white rounded-full px-6 py-4 font-semibold">
                  Êtes-vous vendeur ? Ajoutez vos produits
                </Button>
              </Link>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default HomePage;
