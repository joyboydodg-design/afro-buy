import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { Store, ArrowLeft } from 'lucide-react';
import { ProductCard } from '../components/ProductCard';

const API_URL = process.env.REACT_APP_BACKEND_URL + '/api';

const VendorShopPage = () => {
  const { vendorId } = useParams();
  const [vendor, setVendor] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchVendorData();
  }, [vendorId]);

  const fetchVendorData = async () => {
    try {
      const [vendorRes, productsRes] = await Promise.all([
        axios.get(`${API_URL}/vendors/${vendorId}`),
        axios.get(`${API_URL}/vendors/${vendorId}/products`)
      ]);
      setVendor(vendorRes.data);
      setProducts(productsRes.data);
    } catch (error) {
      console.error('Erreur:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground text-lg">Chargement...</p>
      </div>
    );
  }

  if (!vendor) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground text-lg mb-4">Vendeur non trouvé</p>
          <Link to="/produits">
            <button className="text-primary hover:underline">Retour aux produits</button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12" data-testid="vendor-shop-page">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl">
        <Link to="/produits" className="inline-flex items-center text-primary hover:underline mb-8">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Retour aux produits
        </Link>

        <div className="bg-white rounded-3xl p-8 md:p-12 mb-12">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 bg-gradient-to-br from-primary to-primary-900 rounded-2xl flex items-center justify-center shadow-lg">
              <Store className="h-10 w-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold mb-2" data-testid="vendor-name">{vendor.nom}</h1>
              <p className="text-muted-foreground">{vendor.email}</p>
              {vendor.telephone && (
                <p className="text-muted-foreground">{vendor.telephone}</p>
              )}
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Produits de ce vendeur</h2>
          <p className="text-muted-foreground">{products.length} produit{products.length > 1 ? 's' : ''} disponible{products.length > 1 ? 's' : ''}</p>
        </div>

        {products.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8" data-testid="vendor-products-grid">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-3xl">
            <p className="text-muted-foreground">Ce vendeur n'a pas encore de produits</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default VendorShopPage;
