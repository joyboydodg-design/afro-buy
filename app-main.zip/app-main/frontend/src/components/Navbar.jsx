import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User, Search, Menu, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

export const Navbar = () => {
  const { user, logout } = useAuth();
  const { cartCount } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-border shadow-sm">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary-900 rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-2xl font-bold text-white">A</span>
            </div>
            <span className="text-2xl font-bold text-primary font-sans">AfroBuy</span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            <Link to="/produits" className="text-foreground hover:text-primary font-medium transition-colors">
              Produits
            </Link>
            <Link to="/categories" className="text-foreground hover:text-primary font-medium transition-colors">
              Catégories
            </Link>
          </div>

          <div className="flex items-center gap-4">
            <Link to="/panier" data-testid="cart-button">
              <Button variant="ghost" size="icon" className="relative rounded-full hover:bg-primary/5">
                <ShoppingCart className="h-6 w-6 text-foreground" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-secondary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Button>
            </Link>

            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full hover:bg-primary/5" data-testid="user-menu-button">
                    <User className="h-6 w-6 text-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-3 py-2 border-b border-border">
                    <p className="text-sm font-semibold">{user.nom}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                  </div>
                  {user.role === 'seller' && (
                    <DropdownMenuItem onClick={() => navigate('/vendeur/dashboard')} data-testid="vendor-dashboard-link">
                      Tableau de bord vendeur
                    </DropdownMenuItem>
                  )}
                  {user.role === 'admin' && (
                    <DropdownMenuItem onClick={() => navigate('/admin/dashboard')} data-testid="admin-dashboard-link">
                      Tableau de bord admin
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={handleLogout} data-testid="logout-button">
                    <LogOut className="mr-2 h-4 w-4" />
                    Déconnexion
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link to="/auth">
                <Button className="bg-secondary hover:bg-secondary/90 text-white rounded-full px-6 py-6 font-semibold shadow-lg hover:shadow-xl transition-all" data-testid="login-button">
                  Connexion
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};
