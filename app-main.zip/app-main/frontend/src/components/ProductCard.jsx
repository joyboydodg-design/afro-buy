import React from 'react';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import { Button } from './ui/button';

export const ProductCard = ({ product }) => {
  return (
    <Link to={`/produit/${product.id}`} data-testid={`product-card-${product.id}`}>
      <div className="bg-white rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 border border-transparent hover:border-border/50 group h-full flex flex-col">
        <div className="aspect-square overflow-hidden bg-muted relative">
          {product.images && product.images.length > 0 ? (
            <img
              src={product.images[0]}
              alt={product.nom}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
              Pas d'image
            </div>
          )}
          {product.stock === 0 && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <span className="text-white font-semibold text-lg">Rupture de stock</span>
            </div>
          )}
        </div>
        <div className="p-4 flex-1 flex flex-col">
          <h3 className="font-semibold text-lg mb-2 line-clamp-2 text-foreground group-hover:text-primary transition-colors">
            {product.nom}
          </h3>
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2 flex-1">
            {product.description}
          </p>
          <div className="flex items-center justify-between">
            <span className="text-xl md:text-2xl font-bold text-primary">
              {product.prix.toLocaleString()} FCFA
            </span>
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-accent text-accent" />
              <span className="text-sm font-medium">4.5</span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            par {product.vendeur_nom}
          </p>
        </div>
      </div>
    </Link>
  );
};
