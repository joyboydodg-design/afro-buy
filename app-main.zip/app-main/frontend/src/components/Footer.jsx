import React from 'react';
import { Link } from 'react-router-dom';

export const Footer = () => {
  return (
    <footer className="bg-primary text-white mt-24">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-7xl py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 font-sans">AfroBuy</h3>
            <p className="text-primary-100 text-sm leading-relaxed">
              Votre marketplace local pour le Burkina Faso. Achetez et vendez en toute confiance.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Navigation</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/produits" className="text-primary-100 hover:text-white transition-colors">Produits</Link></li>
              <li><Link to="/categories" className="text-primary-100 hover:text-white transition-colors">Catégories</Link></li>
              <li><Link to="/auth" className="text-primary-100 hover:text-white transition-colors">Devenir vendeur</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-primary-100 hover:text-white transition-colors">Aide</a></li>
              <li><a href="#" className="text-primary-100 hover:text-white transition-colors">Conditions</a></li>
              <li><a href="#" className="text-primary-100 hover:text-white transition-colors">Confidentialité</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <p className="text-primary-100 text-sm">Ouagadougou, Burkina Faso</p>
            <p className="text-primary-100 text-sm mt-2">contact@afrobuy.bf</p>
          </div>
        </div>
        <div className="border-t border-primary-500 mt-8 pt-8 text-center text-sm text-primary-100">
          <p>&copy; 2024 AfroBuy. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
};
