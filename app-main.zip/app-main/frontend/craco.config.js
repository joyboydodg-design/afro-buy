module.exports = {
  webpack: {
    configure: (webpackConfig) => {
      // Find and remove the problematic babel plugin
      webpackConfig.module.rules.forEach(rule => {
        if (rule.oneOf) {
          rule.oneOf.forEach(oneOf => {
            if (oneOf.options && oneOf.options.plugins) {
              oneOf.options.plugins = oneOf.options.plugins.filter(plugin => {
                if (Array.isArray(plugin)) {
                  return !plugin[0]?.includes?.('visual-edits');
                }
                return true;
              });
            }
          });
        }
      });
      return webpackConfig;
    },
  },
};
